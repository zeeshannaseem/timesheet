﻿using System;
using System.Collections.Generic;
using timesheet.model;

namespace timesheet.data.Infrastructure.Interfaces.Repositories
{
    public interface ITaskRepository: IGenericRepository<Task>
    {
        IEnumerable<Task> GetTasks();
        Task GetTasksByEmployeeId(int employeeId);
        IEnumerable<Task> GetEmployeeTasks(int employeeId);
    }
}
