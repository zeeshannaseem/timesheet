﻿using System;
using System.Collections.Generic;
using System.Text;
using timesheet.data.Infrastructure;
using timesheet.model;

namespace timesheet.data.Interfaces.Repositories
{
    public interface ITimeSheetDetailRepository : IGenericRepository<TimeSheetDetails>
    {
        TimeSheetDetails GetSheetByEmployeeId(int employeeID);
    }
}
