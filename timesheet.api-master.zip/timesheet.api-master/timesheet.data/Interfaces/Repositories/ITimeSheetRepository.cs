﻿using System.Collections.Generic;
using timesheet.model;

namespace timesheet.data.Infrastructure.Interfaces
{
    public interface ITimeSheetRepository : IGenericRepository<TimeSheet>
    {
        TimeSheetDetails GetSheetByEmployeeId(int employeeID);
        List<TimeSheet> GetTimeSheetByTaskId(string taskId);
        void UpdateTimeSheet(TimeSheet timeSheet);
        void Save(TimeSheetDetails timeSheet);
    }
}
