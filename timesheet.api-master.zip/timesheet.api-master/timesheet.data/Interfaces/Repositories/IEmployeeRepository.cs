﻿using System;
using System.Collections.Generic;
using System.Text;
using timesheet.model;

namespace timesheet.data.Infrastructure.Interfaces.Repositories
{
   public interface IEmployeeRepository : IGenericRepository<Employee>
    {
        IEnumerable<EmployeeData> GetEmployees();
        Employee GetById(int id);
        void Insert(Employee employee);
    }
}
