﻿using timesheet.data.Infrastructure;
using timesheet.model;

namespace timesheet.data.Interfaces.Services
{
    public interface ITimeSheetDetailService : IEntityService<TimeSheetDetails>
    {
        TimeSheetDetails GetTimeSheet(int id);
        void UpdateTimeSheet(TimeSheetDetails details);
    }
}
