﻿using System;
using System.Collections.Generic;
using System.Text;
using timesheet.data.Infrastructure;
using timesheet.model;

namespace timesheet.data.Interfaces.Services
{
    public interface IEmployeeService : IEntityService<Employee>
    {
        IEnumerable<EmployeeData> GetEmployees();
        Employee GetById(int Id);
    }
}
