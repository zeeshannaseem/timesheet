﻿using System.Collections.Generic;
using timesheet.data.Infrastructure;
using timesheet.model;

namespace timesheet.data.Interfaces.Services
{
    public interface ITimeSheetService : IEntityService<TimeSheet>
    {
        TimeSheetDetails GetTimeSheet(int id);
        List<TimeSheet> GetTimeSheetByTaskId(string taskId);
        void LogTime(TimeSheetDetails timeSheet);
        void UpdateTimeSheet(TimeSheet timeSheet);
    }
}
