﻿using System.Collections.Generic;
using System.Linq;
using timesheet.data.Infrastructure;
using timesheet.data.Infrastructure.Interfaces.Repositories;
using timesheet.model;

namespace timesheet.data.Repositories
{

    public class EmployeeRespository : GenericRepository<Employee>, IEmployeeRepository
    {
        public EmployeeRespository(TimesheetDb context)
            : base(context)
        {

        }

        public IEnumerable<EmployeeData> GetEmployees()
        {
           
            var employees = _entities.Employees.ToList().Select(data => new EmployeeData 
                             {
                                 Id = data.Id,
                                 Code = data.Code,
                                 Name = data.Name,
                                 TotalWeeklyHours = _entities.TimeSheets.Where(x=>x.EmployeeID == data.Id)
                                                                .ToList().Sum(x => (int)x.DayOfWeek),
                                  AverageWeeklyHours = _entities.TimeSheets.Where(x => x.EmployeeID == data.Id)
                                                                .ToList().Sum(x => (int)x.DayOfWeek) / 7,
                             }).ToList();
            return employees;
        }
        public override IEnumerable<Employee> GetAll()
        {
            return _entities.Employees.AsEnumerable();
        }

        public Employee GetById(int id)
        {
            return _dbset.Where(x => x.Id == id).FirstOrDefault();
        }

        public void Insert(Employee employee)
        {
            _dbset.Add(employee);
        }
    }
}
