﻿using System;
using System.Collections.Generic;
using System.Linq;
using timesheet.data.Infrastructure;
using timesheet.data.Infrastructure.Interfaces.Repositories;
using timesheet.model;

namespace timesheet.data.Repositories
{
    public class TaskRepository: GenericRepository<Task>, ITaskRepository
    {
        public TaskRepository(TimesheetDb context) : base(context) { }

        public IEnumerable<Task> GetEmployeeTasks(int employeeId)
        {
            return _entities.Tasks.Where(x => x.EmployeeID == employeeId);
        }

        public IEnumerable<Task> GetTasks()
        {
            return _entities.Tasks.ToList();
        }

        public Task GetTasksByEmployeeId(int employeeId)
        {
            return _entities.Tasks.Where(x => x.EmployeeID == employeeId).FirstOrDefault();
        }
    }
}
