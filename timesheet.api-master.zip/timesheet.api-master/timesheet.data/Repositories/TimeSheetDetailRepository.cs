﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using timesheet.data.Infrastructure;
using timesheet.data.Interfaces.Repositories;
using timesheet.model;

namespace timesheet.data.Repositories
{
   public class TimeSheetDetailRepository: GenericRepository<TimeSheetDetails>, ITimeSheetDetailRepository
    {
        public TimeSheetDetailRepository(TimesheetDb context)
            : base(context)
        {

        }

        public override IEnumerable<TimeSheetDetails> GetAll()
        {
            return null;// _entities.Employees.AsEnumerable();
        }

        public TimeSheetDetails GetSheetByEmployeeId(int id)
        {
            return null; _entities.TimeSheets.Where(x => x.Id == id).FirstOrDefault();
        }

        public void Insert(TimeSheetDetails timeSheet)
        {
            _dbset.Add(timeSheet);

        }

        public void Save(TimeSheetMaster detail)
        {
            _entities.TimeSheetMasters.Add(detail);
        }
    }
}
