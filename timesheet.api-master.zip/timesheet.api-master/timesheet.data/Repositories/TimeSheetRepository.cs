﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using timesheet.data.Infrastructure;
using timesheet.data.Infrastructure.Interfaces;
using timesheet.model;

namespace timesheet.data.Repositories
{
    public class TimeSheetRepository : GenericRepository<TimeSheet>, ITimeSheetRepository
    {
        public TimeSheetRepository(TimesheetDb context)
          : base(context)
        {

        }
        public TimeSheetDetails GetSheetByEmployeeId(int employeeID)
        {
            var log = (from e in _entities.Employees
                       join ts in _entities.Tasks on e.Id equals ts.EmployeeID
                       where e.Id == employeeID
                       select new { emp = e, task = ts }).FirstOrDefault();

            if (log != null)
            {
                var time = _entities.TimeSheets.Where(x => x.TaskID == log.task.Id).FirstOrDefault();
                if (time == null)
                {
                    var taskList = new List<Task>();
                    taskList.Add(new Task
                    {
                        EmployeeID = log.task.EmployeeID,
                        Id = log.task.Id,
                        Name = log.task.Name,
                        Description = log.task.Description
                    });
                    return new TimeSheetDetails
                    {
                        EmployeeID = log.emp.Id,
                        DayOfWeek = 0,
                        Hours = 0,
                        TaskID = log.task.Id,
                        Tasks = taskList.Where(x => x.EmployeeID == log.emp.Id).Select(data => new DailyTask
                        {
                            Id = data.Id,
                            Name = data.Name,
                            Description = data.Description,
                            EmployeeID = data.EmployeeID,
                            HoursPerDay = new List<Days>()
                        }).ToList()
                    };
                };

                var details = new TimeSheetDetails
                {
                    EmployeeID = log.emp.Id,
                    DayOfWeek = time.DayOfWeek,
                    TaskID = time.TaskID,
                    Hours = time.Hours,
                    TimeSheetMasterID = time.TimeSheetMasterID,
                    Tasks = _entities.Tasks.Where(x => x.EmployeeID == log.emp.Id).Select(data => new DailyTask
                    {
                        Id = data.Id,
                        Name = data.Name,
                        Description = data.Description,
                        EmployeeID = data.EmployeeID,
                        HoursPerDay = _entities.TimeSheets.Where(x => x.TaskID == time.TaskID).Select(days => new Days
                        {
                            Id = (int)days.DayOfWeek,
                            Name = Enum.GetName(typeof(WeekDays), days.DayOfWeek),
                            Hours = days.Hours
                        }).ToList()
                    }).ToList()
                };

                return details;
            }
            return null;
        }

        public List<TimeSheet> GetTimeSheetByTaskId(string taskId)
        {
            int id = Convert.ToInt32(taskId);
            return _entities.TimeSheets.Where(x => x.TaskID == id).ToList();
        }

        public void Save(TimeSheetDetails timeSheet)
        {
            TimeSheet time = null;
            var tasks = timeSheet.Tasks.Where(x => x.Id == timeSheet.TaskID).ToList();
            var exists = _entities.TimeSheets.Where(x => x.TaskID == timeSheet.TaskID).ToList();
           
            foreach (var item in tasks)
            {
                foreach (var day in item.HoursPerDay)
                {
                    var timeExists = exists.Where(x => Enum.GetName(typeof(WeekDays), x.DayOfWeek) == day.Name).ToList();
                    if (timeExists.Count > 1)
                    {
                        foreach (var log in timeExists)
                        {
                            _entities.Remove(log);
                        }
                    }

                    if (day.Hours > 0)
                    {
                        time = new TimeSheet();
                        time.DayOfWeek = (WeekDays)day.Id;
                        time.EmployeeID = timeSheet.EmployeeID;
                        time.TaskID = item.Id;
                        time.Hours = day.Hours;
                        time.CreatedOn = DateTime.Now;
                        _dbset.Add(time);
                        _entities.Add(time);
                        _entities.SaveChanges();
                    }
                }

            }
        }

        public void UpdateTimeSheet(TimeSheet timeSheet)
        {
            _dbset.Update(timeSheet);
        }
    }
}
