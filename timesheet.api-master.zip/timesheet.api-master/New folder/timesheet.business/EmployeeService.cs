﻿using System;
using System.Collections.Generic;
using System.Linq;
using timesheet.data;
using timesheet.data.Infrastructure;
using timesheet.data.Infrastructure.Interfaces.Repositories;
using timesheet.data.Interfaces;
using timesheet.data.Interfaces.Services;
using timesheet.model;

namespace timesheet.business
{
    public class EmployeeService: EntityService<data.Employee>, IEmployeeService
    {
        IEmployeeRepository _employeeRepository;

        public EmployeeService(IEmployeeRepository employeeRepository)
            : base(employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }

        public data.Employee GetById(int Id)
        {
            return _employeeRepository.GetById(Id);
        }
    }
}
