﻿using System;
using System.Collections.Generic;
using System.Text;
using timesheet.data;
using timesheet.data.Infrastructure;
using timesheet.data.Infrastructure.Interfaces;
using timesheet.data.Interfaces;
using timesheet.data.Interfaces.Services;

namespace timesheet.business
{
    public class TimeSheetService : EntityService<TimeSheet>, ITimeSheetService
    {
        ITimeSheetRepository _timeSheetRepository;

        public TimeSheetService(ITimeSheetRepository timeSheetRepository)
            : base(timeSheetRepository)
        {
            _timeSheetRepository = timeSheetRepository;
        }

        public void LogTime(TimeSheet timeSheet)
        {
            _timeSheetRepository.Add(timeSheet);
        }


        public TimeSheet GetTimeSheet(int Id)
        {
            return _timeSheetRepository.GetSheetByEmployeeId(Id);
        }

        public void UpdateTimeSheet(TimeSheet timeSheet)
        {
            _timeSheetRepository.UpdateTimeSheet(timeSheet);
        }
    }
}
