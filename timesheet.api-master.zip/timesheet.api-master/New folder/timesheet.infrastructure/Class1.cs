﻿using System;

namespace timesheet.infrastructure
{
    public class Class1
    {
    }
}
