﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace timesheet.model
{
    public class TimeSheet
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int Id { get; set; }

        [ForeignKey("EmployeeID")]
        public int EmployeeID { get; set; }
        [ForeignKey("TaskID")]
        public int TaskID { get; set; }
        public WeekDays DayOfWeek { get; set; }
        public int Hours { get; set; }
        public virtual IEnumerable<Task> Tasks { get; set; }
        public virtual IEnumerable<Employee> Employees { get; set; }
    }

    public enum WeekDays
    {
        Sunday = 1,
        Monday = 2,
        Tuesday = 3,
        Wednesday = 4,
        Thursday = 5,
        Friday = 6,
        Saturday = 7
    }
}
