﻿using System.Collections.Generic;
using System.Linq;
using timesheet.data.Infrastructure;
using timesheet.data.Infrastructure.Interfaces.Repositories;

namespace timesheet.data.Repositories
{

    public class EmployeeRespository : GenericRepository<Employee>, IEmployeeRepository
    {
        public EmployeeRespository(TimesheetDb context)
            : base(context)
        {

        }

        public override IEnumerable<Employee> GetAll()
        {
            return _entities.Set<Employee>().AsEnumerable();
        }

        public Employee GetById(int id)
        {
            return _dbset.Where(x => x.Id == id).FirstOrDefault();
        }

        public void Insert(Employee employee)
        {
            _dbset.Add(employee);
        }
    }
}
