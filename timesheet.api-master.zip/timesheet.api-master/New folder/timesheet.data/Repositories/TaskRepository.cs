﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using timesheet.data.Infrastructure;
using timesheet.data.Infrastructure.Interfaces.Repositories;

namespace timesheet.data.Repositories
{
    public class TaskRepository: GenericRepository<Task>, ITaskRepository
    {
        public TaskRepository(TimesheetDb context) : base(context) { }

        public IEnumerable<Task> GetEmployeeTasks(int employeeId)
        {
            return null;
        }

        public IEnumerable<Task> GetTasks()
        {
            throw new NotImplementedException();
        }

        public Task GetTasksByEmployeeId(int employeeId)
        {
            throw new NotImplementedException();
        }
    }
}
