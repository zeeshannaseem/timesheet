﻿using Microsoft.EntityFrameworkCore;
using System.Linq;
using timesheet.data.Infrastructure;
using timesheet.data.Infrastructure.Interfaces;

namespace timesheet.data.Repositories
{
    public class TimeSheetRepository : GenericRepository<TimeSheet>, ITimeSheetRepository
    {
        public TimeSheetRepository(TimesheetDb context)
          : base(context)
        {

        }
        public TimeSheet GetSheetByEmployeeId(int employeeID)
        {
            return _dbset.Include(t=>t.Tasks).Where(x => x.Id == employeeID).FirstOrDefault();
        }

        public void Save(TimeSheet timeSheet)
        {
            _dbset.Add(timeSheet);
        }

        public void UpdateTimeSheet(TimeSheet timeSheet)
        {
            _dbset.Update(timeSheet);
        }
    }
}
