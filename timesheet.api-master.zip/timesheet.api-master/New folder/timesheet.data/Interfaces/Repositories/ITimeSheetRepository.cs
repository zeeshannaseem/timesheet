﻿namespace timesheet.data.Infrastructure.Interfaces
{
    public interface ITimeSheetRepository : IGenericRepository<TimeSheet>
    {
        TimeSheet GetSheetByEmployeeId(int employeeID);
        void UpdateTimeSheet(TimeSheet timeSheet);
        void Save(TimeSheet timeSheet);
    }
}
