﻿using System;
using System.Collections.Generic;
using System.Text;

namespace timesheet.data.Interfaces.Repositories
{
    class Class1
    {
    }
}
