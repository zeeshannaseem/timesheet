﻿using System;
using System.Collections.Generic;
using System.Text;

namespace timesheet.data.Infrastructure.Interfaces.Repositories
{
   public interface IEmployeeRepository : IGenericRepository<Employee>
    {
        Employee GetById(int id);
        void Insert(Employee employee);
    }
}
