﻿using System;
using System.Collections.Generic;
using System.Text;
using timesheet.data.Infrastructure;

namespace timesheet.data.Interfaces.Services
{
    public interface ITaskService : IEntityService<Task>
    {
        IEnumerable<Task> GetTasks();
        Task GetTasksByEmployeeId(int employeeId);
        IEnumerable<Task> GetEmployeeTasks(int employeeId);
    }
}
