﻿using timesheet.data.Infrastructure;

namespace timesheet.data.Interfaces.Services
{
    public interface ITimeSheetService : IEntityService<TimeSheet>
    {
        TimeSheet GetTimeSheet(int id);
        void LogTime(TimeSheet timeSheet);
        void UpdateTimeSheet(TimeSheet timeSheet);
    }
}
