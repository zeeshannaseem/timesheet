﻿using System;
using System.Collections.Generic;
using System.Text;
using timesheet.data.Infrastructure;

namespace timesheet.data.Interfaces.Services
{
    public interface IEmployeeService : IEntityService<Employee>
    {
        Employee GetById(int Id);
    }
}
