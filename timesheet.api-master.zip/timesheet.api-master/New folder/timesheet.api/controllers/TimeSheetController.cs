﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using timesheet.business;
using timesheet.data;
using timesheet.data.Interfaces;
using timesheet.data.Interfaces.Services;

namespace timesheet.api.controllers
{
    [Route("api/v1/timesheet")]
    [ApiController]
    public class TimeSheetController : Controller
    {
        private readonly ITimeSheetService _timesheetSerivce;
        public TimeSheetController(ITimeSheetService timesheetSerivce)
        {
            _timesheetSerivce = timesheetSerivce;
        }

        [HttpGet("gettimesheet")]
        public IActionResult GetTimeSheet(int employeeId)
        {
           // return Ok(_timesheetSerivce.GetTimeSheet(employeeId));
            return Ok(GetSheet());
        }

        [HttpPost("logtime")]
        public IActionResult LogTime(TimeSheet timeSheet)
        {
            _timesheetSerivce.LogTime(timeSheet);
            return Ok();
        }

        public TimeSheet GetSheet()
        {
            return new TimeSheet
            {
                DayOfWeek = WeekDays.Sunday,
                TaskID = 4,
                EmployeeID = 6,
                Hours = 6,
                Tasks = new List<Task> {
                    { new Task { Name="Test", Description="Shani", EmployeeID=6 } },
                    { new Task { Name="Testing", Description="new tasj=k", EmployeeID=6 }}

                },                
            };
        }
    }
}