﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using timesheet.data.Interfaces.Services;

namespace timesheet.api.controllers
{
    [Route("api/v1/task")]
    [ApiController]
    public class TaskController : Controller
    {
        private readonly ITaskService _taskService;
        public TaskController(ITaskService service)
        {
            _taskService = service;
        }

        [HttpGet("gettasks")]
        public IActionResult GetTasks()
        {
            return Ok(_taskService.GetTasks());
        }

        [HttpGet("gettasksbyId")]
        public IActionResult GetTasks(int id)
        {
            return Ok(_taskService.GetTasksByEmployeeId(id));
        }
    }
}