﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using timesheet.business;
using timesheet.data;
using timesheet.data.Interfaces;
using timesheet.data.Interfaces.Services;
using timesheet.model;

namespace timesheet.api.controllers
{
    [Route("api/v1/timesheet")]
    [ApiController]
    public class TimeSheetController : Controller
    {
        private readonly ITimeSheetService _timesheetSerivce;
        public TimeSheetController(ITimeSheetService timesheetSerivce)
        {
            _timesheetSerivce = timesheetSerivce;
        }

        [HttpGet("gettimesheet")]
        public IActionResult GetTimeSheet(string employeeId)
        {
            int id = Convert.ToInt32(employeeId);
           var timsheet = _timesheetSerivce.GetTimeSheet(id);
            return Ok(timsheet);
          //  return Ok(GetSheet());
        }

        [HttpGet("getTimeSheetByTaskId")]
        public IActionResult GetTimeSheetByTaskId(string taskId)
        {
              var timsheet = _timesheetSerivce.GetTimeSheetByTaskId(taskId);
              return Ok(timsheet);
            //return Ok(GetSheet());
        }

        [HttpPost("logTimeSheet")]
        public IActionResult LogTimeSheet([FromBody] TimeSheetDetails timeSheet)
        {
            _timesheetSerivce.LogTime(timeSheet);
            return Ok();
        }

       
    }
}