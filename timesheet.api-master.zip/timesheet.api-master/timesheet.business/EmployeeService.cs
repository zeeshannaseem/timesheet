﻿using System.Collections.Generic;
using timesheet.data.Infrastructure;
using timesheet.data.Infrastructure.Interfaces.Repositories;
using timesheet.data.Interfaces.Services;
using timesheet.model;

namespace timesheet.business
{
    public class EmployeeService: EntityService<Employee>, IEmployeeService
    {
        IEmployeeRepository _employeeRepository;

        public EmployeeService(IEmployeeRepository employeeRepository)
            : base(employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }

        public Employee GetById(int Id)
        {
            return _employeeRepository.GetById(Id);
        }

        public IEnumerable<EmployeeData> GetEmployees()
        {
            return _employeeRepository.GetEmployees();
        }
    }
}
