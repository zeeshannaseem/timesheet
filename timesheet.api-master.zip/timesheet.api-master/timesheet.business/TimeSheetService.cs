﻿using System;
using System.Collections.Generic;
using System.Text;
using timesheet.data;
using timesheet.data.Infrastructure;
using timesheet.data.Infrastructure.Interfaces;
using timesheet.data.Interfaces;
using timesheet.data.Interfaces.Services;
using timesheet.model;

namespace timesheet.business
{
    public class TimeSheetService : EntityService<TimeSheet>, ITimeSheetService
    {
        ITimeSheetRepository _timeSheetRepository;

        public TimeSheetService(ITimeSheetRepository timeSheetRepository)
            : base(timeSheetRepository)
        {
            _timeSheetRepository = timeSheetRepository;
        }

        public void LogTime(TimeSheetDetails timeSheet)
        {
            _timeSheetRepository.Save(timeSheet);
        }

        public TimeSheetDetails GetTimeSheet(int id)
        {
            return _timeSheetRepository.GetSheetByEmployeeId(id);
        }

        public void UpdateTimeSheet(TimeSheet timeSheet)
        {
            _timeSheetRepository.UpdateTimeSheet(timeSheet);
        }

        public List<TimeSheet> GetTimeSheetByTaskId(string taskId)
        {
          return  _timeSheetRepository.GetTimeSheetByTaskId(taskId);
        }
    }
}
