﻿using System;
using System.Collections.Generic;
using System.Text;
using timesheet.data;
using timesheet.data.Infrastructure;
using timesheet.data.Infrastructure.Interfaces.Repositories;
using timesheet.data.Interfaces.Services;
using timesheet.model;

namespace timesheet.business
{
   public class TaskService : EntityService<Task>, ITaskService
    {
        ITaskRepository _taskRepository;

        public TaskService(ITaskRepository taskRepository)
            : base(taskRepository)
        {
            _taskRepository = taskRepository;
        }

        public IEnumerable<Task> GetById(int Id)
        {
            return _taskRepository.GetEmployeeTasks(Id);
        }

        public IEnumerable<Task> GetEmployeeTasks(int employeeId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Task> GetTasks()
        {
            return _taskRepository.GetTasks();
        }

        public IEnumerable<Task> GetTasksByEmployeeId(int employeeId)
        {
            return _taskRepository.GetEmployeeTasks(employeeId);
        }

        Task ITaskService.GetTasksByEmployeeId(int employeeId)
        {
            throw new NotImplementedException();
        }
    }
}
