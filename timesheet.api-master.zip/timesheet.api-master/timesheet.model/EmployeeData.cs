﻿using System;
using System.Collections.Generic;
using System.Text;

namespace timesheet.model
{
   public class EmployeeData
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public int TotalWeeklyHours { get; set; }
        public int AverageWeeklyHours { get; set; }
    }
}
