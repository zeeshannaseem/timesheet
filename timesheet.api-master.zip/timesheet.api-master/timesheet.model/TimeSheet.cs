﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace timesheet.model
{
    public class TimeSheet
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int Id { get; set; }
        
        public int EmployeeID { get; set; }  
        public int TaskID { get; set; }
        public int TimeSheetMasterID { get; set; }
        public WeekDays DayOfWeek { get; set; }
        public int Hours { get; set; }
        public DateTime CreatedOn { get; set; }
    }

    public enum WeekDays
    {
        Sunday = 1,
        Monday = 2,
        Tuesday = 3,
        Wednesday = 4,
        Thursday = 5,
        Friday = 6,
        Saturday = 7
    }
}
