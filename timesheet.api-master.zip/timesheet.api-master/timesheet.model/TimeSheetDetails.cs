﻿using System;
using System.Collections.Generic;
using System.Text;

namespace timesheet.model
{
   public class TimeSheetDetails
    {
        public int EmployeeID { get; set; }
        public int TaskID { get; set; }
        public int TimeSheetMasterID { get; set; }
        public WeekDays DayOfWeek { get; set; }
        public int Hours { get; set; }
        public IEnumerable<DailyTask> Tasks { get; set; }
        
    }

    public class Days
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Hours { get; set; }
    }

    public class DailyTask: Task
    {
        public List<Days> HoursPerDay { get; set; }
    }
}
